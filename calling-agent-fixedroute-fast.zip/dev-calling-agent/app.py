from src.rag.knowledge_base import RAGSystem
obj = RAGSystem(
    embeddings_model="sentence-transformers/all-MiniLM-L6-v2",
    file_path=r"D:\GENAIProjects\calling-repasentive-ai\calling-agent\data"
)

obj.run_piepline()